CREATE VIEW dbo.V_book
AS
SELECT   dbo.tb_book.ID, dbo.tb_subType.superType AS superID, dbo.tb_superType.TypeName AS supertype, 
                dbo.tb_subType.ID AS subID, dbo.tb_subType.TypeName AS subtype, dbo.tb_book.bookName, dbo.tb_book.introduce, 
                dbo.tb_book.price, dbo.tb_book.nowPrice, dbo.tb_book.picture, dbo.tb_book.newBook, dbo.tb_book.sale
FROM      dbo.tb_superType RIGHT OUTER JOIN
                dbo.tb_subType ON dbo.tb_superType.ID = dbo.tb_subType.superType RIGHT OUTER JOIN
                dbo.tb_book ON dbo.tb_subType.ID = dbo.tb_book.typeID
go

