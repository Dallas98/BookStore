CREATE VIEW dbo.V_order_detail
AS
SELECT   dbo.tb_order_detail.orderID, dbo.tb_order_detail.bookID, dbo.tb_book.bookName, dbo.tb_order_detail.price, 
                dbo.tb_order_detail.number
FROM      dbo.tb_order_detail INNER JOIN
                dbo.tb_book ON dbo.tb_order_detail.bookID = dbo.tb_book.ID
go

