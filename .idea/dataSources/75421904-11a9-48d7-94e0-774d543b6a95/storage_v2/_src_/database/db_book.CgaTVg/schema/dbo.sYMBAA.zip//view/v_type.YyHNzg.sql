CREATE VIEW dbo.V_Type
AS
SELECT dbo.tb_superType.ID, dbo.tb_superType.TypeName AS superType, 
      dbo.tb_subType.TypeName AS subType, dbo.tb_subType.ID AS subID
FROM dbo.tb_superType INNER JOIN
      dbo.tb_subType ON dbo.tb_superType.ID = dbo.tb_subType.superType
go

