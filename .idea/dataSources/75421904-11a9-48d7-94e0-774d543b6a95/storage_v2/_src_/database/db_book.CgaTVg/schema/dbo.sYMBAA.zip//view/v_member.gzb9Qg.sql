CREATE VIEW dbo.V_Member
AS
SELECT dbo.tb_Member.ID, dbo.tb_Member.TrueName, dbo.tb_Member.city, 
      dbo.tb_Member.address, dbo.tb_Member.postcode, dbo.tb_Member.username, 
      dbo.tb_Member.CardNO, dbo.tb_Member.CardType, dbo.tb_Member.grade, 
      dbo.tb_Member.Amount, dbo.tb_Member.Tel, dbo.tb_Member.Email, 
      dbo.tb_rebate.rebate
FROM dbo.tb_Member INNER JOIN
      dbo.tb_rebate ON dbo.tb_Member.grade = dbo.tb_rebate.grade
go

